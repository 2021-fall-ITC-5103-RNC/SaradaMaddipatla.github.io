$(document).ready(function () {
  $.getJSON("westpackage.json", function (data) {
    console.log(data);
    $.each(data.westplaces, function (index, each) {
        $("#westcontent").append("<div style='font-size: 32px; color: #005870; margin-bottom: 20px;'>" + each.heading + "</div>");
        $("#westcontent").append("<img  src=" + each.image + " width='80%' height='550px' />");
        $("#westcontent").append("<div style='padding-left: 150px; padding-right: 150px; font-size: 20px; color: #5050505; margin-bottom: 20px; margin-top: 20px; text-align: left;'>" + each.info + "</div>");
    });
  });
});
