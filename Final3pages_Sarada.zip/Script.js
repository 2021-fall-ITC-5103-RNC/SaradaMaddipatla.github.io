function Submit() {
    var firstName = document.getElementById("firstname").value;
    var lastName = document.getElementById("lastname").value;
    var email = document.getElementById("emailid").value;
    var phonenumber = document.getElementById("phonenumber").value;
    var address = document.getElementById("address").value;
    var message = document.getElementById("message").value;
    var errorfname=document.getElementById("errorfname");
    var errorlname=document.getElementById("errorlname");
    var erroremail=document.getElementById("erroremail");
    var errorphone=document.getElementById("errorphone");
    var erroraddress=document.getElementById("erroraddress");
    var errormessage=document.getElementById("errormessage");
    var error;
    
   

    if(firstName == "" || firstName.length > 10)
    {
        error="Please enter your first name";
        errorfname.innerHTML= error;
    }
    if(lastName == "" || lastName.length > 10)
    {
        error="Please enter your last name";
        errorlname.innerHTML= error;
    }
    if(email.indexOf("@") == -1 )
    { 
        error="Please enter valid email ";
        erroremail.innerHTML= error; 
    }
    if(phonenumber == "" || phonenumber == null)
    {
        error="Please enter valid phone Number ";
        errorphone.innerHTML= error;
    }
    if(address == "")
    {
        error="Please enter correct address";
        erroraddress.innerHTML= error;
    }
    if(message == "")
    { 
        error="Please enter the data";
        errormessage.innerHTML= error;
    }
    if(error== " "){
        alert("Form Submitted Sucessfully");
    }
    else{
        document.getElementById("submitform");
        return false;
    }
}