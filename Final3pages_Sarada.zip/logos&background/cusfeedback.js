function validation() {
    var emailid = document.getElementById("emailid").value;
    var nameid = document.getElementById("nameid").value;
    var commentsid = document.getElementById("commentsid").value;
    var emailvalidate = document.getElementById("emailvalidate");
    var namevalidate = document.getElementById("namevalidate");
    var commentsvalidate = document.getElementById("commentsvalidate");
    var text=" ";


    if (nameid.length < 5) {
        text = "Please enter your name correctly";
        namevalidate.innerHTML = text;
    }
    if (emailid.indexOf("@") == -1) {
        text = "Please Enter Valid EmailId";
        emailvalidate.innerHTML = text;
    }
    if (commentsid.length < 50) {
        text = "Please enter your valuable comments";
        commentsvalidate.innerHTML = text;
    }
    if (text == " ") {
        alert("Form Submited Sucessfully");
    }
    else {
        document.getElementById("SubmitForm");
        return false;

    }

}
