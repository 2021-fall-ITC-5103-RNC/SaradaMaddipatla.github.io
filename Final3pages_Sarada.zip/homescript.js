var photos = [];
var time = 1000;
var i=0;
photos[0] = 'logos&background/background3.jpg';
photos[1] = 'logos&background/background5.jpg';
photos[2] = 'logos&background/background6.jpg';
photos[3] = 'logos&background/background8.jpg';

function scrollImg(){

    document.slide.src = photos[i];

    if(i < photos.length -1){
        i++;
    }else
    {
        i=0;
    }

    setTimeout("scrollImg()", time);
    

}

window.onload = scrollImg;